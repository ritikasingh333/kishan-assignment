<?php

namespace Omnipay\Common\Exception;

/**
 * Runtime Exception
 */
class RuntimeException extends \RuntimeException implements OmnipayException
{
}
